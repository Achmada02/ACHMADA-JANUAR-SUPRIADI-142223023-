# Analisis Data Mining Suporter Persebaya
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("dataset_suporter_persebaya_100.csv")

fitur = df[["Umur","Frekuensi_Nonton","Pengeluaran_Merchandise"]]

scaler = StandardScaler()
X = scaler.fit_transform(fitur)

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X)

print(df.head())
print("\nJumlah anggota tiap cluster:")
print(df["Cluster"].value_counts())

df.to_csv("hasil_clustering_bonek.csv", index=False)
print("File hasil_clustering_bonek.csv berhasil dibuat.")
