import streamlit as st
import pandas as pd
import plotly.express as px
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

st.set_page_config(page_title="Dashboard Data Mining Bonek", layout="wide")
st.title("⚽ Dashboard Data Mining Suporter Persebaya (Bonek)")

df = pd.read_csv("dataset_suporter_persebaya_100.csv")

st.header("Dataset")
st.dataframe(df)

st.header("Statistik Deskriptif")
st.write(df.describe())

st.header("Visualisasi")

col1, col2 = st.columns(2)

with col1:
    kota = df["Kota_Asal"].value_counts().reset_index()
    kota.columns = ["Kota", "Jumlah"]
    fig = px.bar(kota, x="Kota", y="Jumlah", title="Jumlah Suporter per Kota")
    st.plotly_chart(fig, use_container_width=True)

with col2:
    loyal = df["Loyalitas"].value_counts().reset_index()
    loyal.columns = ["Loyalitas", "Jumlah"]
    fig2 = px.pie(loyal, names="Loyalitas", values="Jumlah", title="Distribusi Loyalitas")
    st.plotly_chart(fig2, use_container_width=True)

st.header("Clustering K-Means")

fitur = df[["Umur","Frekuensi_Nonton","Pengeluaran_Merchandise"]]
scaler = StandardScaler()
X = scaler.fit_transform(fitur)

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X)

st.dataframe(df[["ID_Suporter","Nama","Cluster"]])

fig3 = px.scatter(
    df,
    x="Frekuensi_Nonton",
    y="Pengeluaran_Merchandise",
    color=df["Cluster"].astype(str),
    hover_data=["Nama"],
    title="Hasil Clustering Suporter"
)
st.plotly_chart(fig3, use_container_width=True)

st.download_button(
    "Download Hasil Clustering",
    df.to_csv(index=False),
    file_name="hasil_clustering_bonek.csv",
    mime="text/csv"
)
